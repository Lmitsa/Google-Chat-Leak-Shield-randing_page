// Google Chat Real-Time Leak Detector - Background Service Worker

// Cyber-Security Sheriff System Instruction Generator
function getSystemInstruction(customRules = []) {
  let customRulesText = "";
  if (customRules && customRules.length > 0) {
    customRulesText = `\n8. Custom Organization Rules: The user has defined the following specific strings/patterns as HIGHLY SENSITIVE leaks. If the message contains any of these, it MUST be flagged as a leak:\n  - ${customRules.join('\n  - ')}\n  -> Category: "Custom Rule", Risk Level: "CRITICAL", Reason: "사내 커스텀 보안 정책 위반"`;
  }

  return `You are an expert enterprise cyber-security sheriff. Your job is to analyze the following message typed in an internal corporate messenger and check for potential sensitive data leaks.

You must enforce an EXTREMELY strict policy. The following items MUST ALWAYS be flagged as a leak ("isLeak": true):
1. Any Korean Business Registration Number (사업자등록번호, format: xxx-xx-xxxxx) -> Category: "PII" or "Other", Risk Level: "WARNING". Reason: "사업자등록번호 노출 위험"
2. Any Private or Internal IP Address (e.g., 192.168.x.x, 10.x.x.x, 172.16.x.x-172.31.x.x) -> Category: "Database" or "Other", Risk Level: "WARNING" or "CRITICAL" depending on context. Reason: "내부 서버 IP 주소 노출 위험"
3. Credentials (AWS Keys, Google Cloud API Keys, GitHub Access Tokens, JWT Tokens, SSH/TLS Private Keys, API secrets) -> Category: "Credential", Risk Level: "CRITICAL"
4. Source Code (Proprietary code snippets, database configurations, business logic algorithms) -> Category: "Source Code", Risk Level: "WARNING"
5. Database connection strings, credentials, hosts, endpoints -> Category: "Database", Risk Level: "CRITICAL"
6. Personally Identifiable Information (PII) like Korean Resident Registration Numbers, Phone Numbers, Email addresses, Driver's License Numbers, Passport Numbers -> Category: "PII", Risk Level: "CRITICAL" or "WARNING"
7. Financial Data (Credit Card numbers, Bank Account numbers) -> Category: "Financial", Risk Level: "CRITICAL"${customRulesText}

CRITICAL OUTPUT REQUIREMENT (STRICT JSON ONLY):
Provide your evaluation strictly and ONLY as a raw JSON object matching the exact schema below. 
- DO NOT include any conversational text, greetings, explanations (e.g., "Here is the response...").
- DO NOT wrap the output in markdown fences like \`\`\`json.
- Even if the text is completely SAFE and there is NO LEAK, you MUST still output a valid JSON object with "isLeak": false.
- The JSON output MUST NOT contain any code comments (like //).

JSON Schema to strictly follow:
{
  "isLeak": false,
  "riskLevel": "INFO",
  "category": "System",
  "reason": "안전함",
  "leakSnippet": ""
}

Field Requirements:
- "isLeak": boolean (true if ANY rule is violated, false otherwise)
- "riskLevel": string ("CRITICAL", "WARNING", or "INFO")
- "category": string ("Credential", "Source Code", "Database", "PII", "Financial", "Custom Rule", "System", or "Other")
- "reason": string (Short user-friendly explanation in Korean)
- "leakSnippet": string (The specific leaked string or code fragment. Leave empty if safe.)`;
}



// Monitor incoming messages from Content Script and Options Page
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'analyze_text') {
    handleTextAnalysis(message.text)
      .then(result => sendResponse({ success: true, data: result }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true; // Keep the message channel open for asynchronous response
  }

  if (message.action === 'test_api_key') {
    testApiKey(message.apiKey)
      .then(result => sendResponse({ success: true, data: result }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true; // Keep the message channel open for asynchronous response
  }

  if (message.action === 'log_leak') {
    handleLogLeak(message.leak)
      .then(() => sendResponse({ success: true }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true; // Keep the message channel open for asynchronous response
  }
});

// JSON 추출 유틸 함수 — 대화형 텍스트가 섞인 응답에서도 순수 JSON 객체/배열만 복구
function extractJsonFromText(text) {
  let clean = (text || '').trim();

  // 1. 마크다운 코드 블록(```json ... ```) 내부 추출
  const mdMatch = clean.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  if (mdMatch) clean = mdMatch[1].trim();

  // 2. 첫 번째 {/[ 부터 마지막 }/] 까지 추출
  const firstBrace = clean.indexOf('{');
  const firstBracket = clean.indexOf('[');
  const lastBrace = clean.lastIndexOf('}');
  const lastBracket = clean.lastIndexOf(']');

  let startIdx = -1, endIdx = -1;
  if (firstBrace !== -1 && firstBracket !== -1) {
    if (firstBrace < firstBracket) { startIdx = firstBrace; endIdx = lastBrace; }
    else { startIdx = firstBracket; endIdx = lastBracket; }
  } else if (firstBrace !== -1) { startIdx = firstBrace; endIdx = lastBrace; }
  else if (firstBracket !== -1) { startIdx = firstBracket; endIdx = lastBracket; }

  if (startIdx !== -1 && endIdx !== -1 && endIdx >= startIdx) {
    try { return JSON.parse(clean.substring(startIdx, endIdx + 1)); }
    catch { return null; }
  }
  return null;
}

// Perform Secure LLM Analysis using Gemini API
async function executeGeminiRequest(model, apiKey, text, customRules = [], retries = 2, delay = 1000) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

  const payload = {
    contents: [
      {
        role: 'user',
        parts: [
          { text: text }
        ]
      }
    ],
    systemInstruction: {
      parts: [
        { text: getSystemInstruction(customRules) } // 여기서 동적 함수 호출
      ]
    },
    generationConfig: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: 'OBJECT',
        properties: {
          isLeak: { type: 'BOOLEAN' },
          riskLevel: { type: 'STRING', enum: ['CRITICAL', 'WARNING', 'INFO'] },
          category: { type: 'STRING' },
          reason: { type: 'STRING' },
          leakSnippet: { type: 'STRING' }
        },
        required: ['isLeak', 'riskLevel', 'category', 'reason', 'leakSnippet']
      },
      maxOutputTokens: 1024
    }
  };

  for (let i = 0; i <= retries; i++) {
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      // 안전한 응답 처리: response.json() 대신 response.text()로 먼저 수신
      const responseBody = await response.text();

      if (!response.ok) {
        let errorMessage = `HTTP error ${response.status}`;
        try {
          const errorData = JSON.parse(responseBody);
          errorMessage = errorData.error?.message || errorMessage;
        } catch { /* body가 JSON이 아닌 경우 무시 */ }
        throw new Error(errorMessage);
      }

      // 1차: 정상 JSON 응답 파싱 시도
      let responseData;
      try {
        responseData = JSON.parse(responseBody);
      } catch (parseErr) {
        // HTTP 200이지만 body가 JSON이 아닌 경우 — body 자체에서 JSON 추출 시도
        console.warn('[LeakShield] response body is not valid JSON, attempting raw text extraction:', parseErr.message);
        const extracted = extractJsonFromText(responseBody);
        if (extracted) return extracted;
        throw new Error('API returned non-JSON response: ' + responseBody.substring(0, 100));
      }

      const candidate = responseData.candidates?.[0];
      const rawText = candidate?.content?.parts?.[0]?.text;
      const finishReason = candidate?.finishReason;

      if (!rawText) {
        throw new Error(`Returned an empty or invalid structure. Finish reason: ${finishReason || 'UNKNOWN'}`);
      }

      if (finishReason === 'SAFETY') {
        throw new Error('API Safety filter blocked the response.');
      } else if (finishReason === 'MAX_TOKENS') {
        console.warn('[LeakShield] API response was truncated due to MAX_TOKENS.');
      }

      // 2차: rawText에서도 대화형 텍스트가 섞여 있을 수 있으므로 extractJsonFromText로 추출
      const extracted = extractJsonFromText(rawText);
      if (extracted) return extracted;

      // 3차: rawText 자체가 순수 JSON일 수 있으므로 직접 파싱 시도
      try {
        return JSON.parse(rawText.trim());
      } catch (parseErr) {
        throw new Error(`Failed to parse AI response. Raw output: ${rawText.substring(0, 50)}. Parse error: ${parseErr.message}`);
      }

    } catch (error) {
      const errorMsg = error.message || "";
      const isTransient = errorMsg.includes("high demand") || errorMsg.includes("overloaded") || errorMsg.includes("503") || errorMsg.includes("Unavailable") || errorMsg.includes("ResourceExhausted") || errorMsg.includes("429") || errorMsg.includes("quota") || errorMsg.includes("limit");

      if (isTransient && i < retries) {
        console.warn(`[LeakShield] Transient API error on ${model} (attempt ${i + 1}/${retries + 1}): ${errorMsg}. Retrying in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
        delay *= 2; // Exponential backoff
        continue;
      }
      throw new Error(`Gemini API Error (${model}): ${errorMsg}`);
    }
  }
}

// Perform Secure LLM Analysis using Gemini API with automatic fallback
// Perform Secure LLM Analysis using Gemini API with automatic fallback
async function handleTextAnalysis(text) {
  // 1. Retrieve the secure API Key from chrome.storage.local
  const storage = await chrome.storage.local.get(['gemini_api_key', 'stats', 'custom_regexes']);
  const apiKey = storage.gemini_api_key;
  const customRegexes = storage.custom_regexes || [];

  if (!apiKey) {
    throw new Error('Gemini API key is not configured. Please set it in the Extension Options page.');
  }

  let parsedResult;
  let modelUsed = 'gemini-2.5-flash';

  try {
    parsedResult = await executeGeminiRequest(modelUsed, apiKey, text, customRegexes);
  } catch (error) {
    const errorMsg = error.message || "";
    const isOverloaded = errorMsg.includes("high demand") || errorMsg.includes("overloaded") || errorMsg.includes("503") || errorMsg.includes("Unavailable") || errorMsg.includes("ResourceExhausted") || errorMsg.includes("quota") || errorMsg.includes("limit");

    if (isOverloaded) {
      console.warn(`[LeakShield] Primary model ${modelUsed} overloaded. Attempting fallback to gemini-1.5-flash...`);
      try {
        modelUsed = 'gemini-1.5-flash';
        parsedResult = await executeGeminiRequest(modelUsed, apiKey, text, customRegexes);
        console.log(`[LeakShield] Fallback to ${modelUsed} successful.`);
      } catch (fallbackError) {
        console.error("[LeakShield] Fallback model also failed:", fallbackError);
        throw error; // throw the original error if fallback also fails
      }
    } else {
      throw error;
    }
  }

  // 3. Normalize if AI returned an array of objects (due to multiple matches in a single prompt)
  if (Array.isArray(parsedResult)) {
    console.log("[LeakShield] AI returned an array of evaluations. Normalizing...");
    const leaks = parsedResult.filter(item => item && item.isLeak);
    if (leaks.length > 0) {
      const hasCritical = leaks.some(item => item.riskLevel === 'CRITICAL');
      const riskLevel = hasCritical ? 'CRITICAL' : 'WARNING';

      const categories = [...new Set(leaks.map(item => item.category).filter(Boolean))];
      const category = categories.length > 0 ? categories.join(', ') : 'Other';

      const reasons = [...new Set(leaks.map(item => item.reason).filter(Boolean))];
      const reason = reasons.length > 0 ? reasons.join(' / ') : '민감 정보 유출 위험 감지';

      const snippets = [...new Set(leaks.map(item => item.leakSnippet).filter(Boolean))];
      const leakSnippet = snippets.length > 0 ? snippets.join(', ') : '';

      parsedResult = {
        isLeak: true,
        riskLevel: riskLevel,
        category: category,
        reason: reason,
        leakSnippet: leakSnippet
      };
    } else {
      parsedResult = {
        isLeak: false,
        riskLevel: 'INFO',
        category: 'System',
        reason: '안전함',
        leakSnippet: ''
      };
    }
  }

  // 4. Update Statistics on Leaks
  let stats = storage.stats || { scanned: 0, regexBlocked: 0, llmFlagged: 0, savedLeaks: 0 };
  stats.scanned = (stats.scanned || 0) + 1;
  stats.regexBlocked = (stats.regexBlocked || 0) + 1;

  if (parsedResult.isLeak) {
    stats.llmFlagged = (stats.llmFlagged || 0) + 1;

    // Save to historical leak logs
    const historyData = await chrome.storage.local.get(['leak_logs']);
    let leakLogs = historyData.leak_logs || [];

    const newLog = {
      id: 'leak_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
      timestamp: new Date().toISOString(),
      snippet: parsedResult.leakSnippet || text.substring(0, 100),
      category: parsedResult.category || 'Other',
      riskLevel: parsedResult.riskLevel || 'WARNING',
      reason: parsedResult.reason || '잠재적인 보안 유출 위험이 감지되었습니다.',
      fullText: text
    };

    // Keep max 50 logs for storage space optimization
    leakLogs.unshift(newLog);
    if (leakLogs.length > 50) {
      leakLogs.pop();
    }

    await chrome.storage.local.set({
      leak_logs: leakLogs,
      stats: stats
    });
  } else {
    await chrome.storage.local.set({ stats: stats });
  }

  return parsedResult;
}

// Diagnostics helper to test key connectivity and validity with fallback support
async function testApiKey(apiKey) {
  if (!apiKey) {
    throw new Error('API Key is empty.');
  }

  try {
    return await executeTestRequest('gemini-2.5-flash', apiKey);
  } catch (error) {
    const errorMsg = error.message || "";
    const isOverloaded = errorMsg.includes("high demand") || errorMsg.includes("overloaded") || errorMsg.includes("503") || errorMsg.includes("Unavailable") || errorMsg.includes("ResourceExhausted") || errorMsg.includes("quota") || errorMsg.includes("limit");

    if (isOverloaded) {
      try {
        console.warn("[LeakShield] Testing connection fallback to gemini-1.5-flash...");
        return await executeTestRequest('gemini-1.5-flash', apiKey);
      } catch (fallbackError) {
        throw error;
      }
    }
    throw error;
  }
}

async function executeTestRequest(model, apiKey) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

  const payload = {
    contents: [
      {
        role: 'user',
        parts: [
          { text: 'Ping' }
        ]
      }
    ],
    generationConfig: {
      maxOutputTokens: 5
    }
  };

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const errorMessage = errorData.error?.message || `HTTP error ${response.status}`;
    throw new Error(errorMessage);
  }

  return { status: 'connected', model: model };
}

// Log locally confirmed leak blocks directly
async function handleLogLeak(leakData) {
  const storage = await chrome.storage.local.get(['stats', 'leak_logs']);
  let stats = storage.stats || { scanned: 0, regexBlocked: 0, llmFlagged: 0, savedLeaks: 0 };
  stats.scanned = (stats.scanned || 0) + 1;
  stats.regexBlocked = (stats.regexBlocked || 0) + 1;

  let leakLogs = storage.leak_logs || [];

  // Check if we already logged this exact snippet within the last 5 seconds to avoid duplicates
  const now = Date.now();
  const isDuplicate = leakLogs.some(log => {
    const logTime = new Date(log.timestamp).getTime();
    return log.snippet === leakData.snippet && (now - logTime < 5000);
  });

  if (isDuplicate) {
    return;
  }

  const newLog = {
    id: 'leak_' + now + '_' + Math.random().toString(36).substr(2, 5),
    timestamp: new Date().toISOString(),
    snippet: leakData.snippet || '',
    category: leakData.category || 'Other',
    riskLevel: leakData.riskLevel || 'CRITICAL',
    reason: leakData.reason || '보안 유출 위험이 감지되었습니다.',
    fullText: leakData.fullText || ''
  };

  leakLogs.unshift(newLog);
  if (leakLogs.length > 50) {
    leakLogs.pop();
  }

  await chrome.storage.local.set({
    leak_logs: leakLogs,
    stats: stats
  });
}
