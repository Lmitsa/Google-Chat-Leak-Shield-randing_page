// Google Chat Real-Time Leak Detector - Content Script

let debounceTimer = null;
let lastAnalyzedText = "";
let pendingAnalysis = null; // Globally tracks the active AI request
let activeWarningToastId = null;
let lastAnalysisResult = null; // Caches the last AI analysis result: { text, result }
let lastBgApiCallTime = 0; // Tracks the timestamp of the last background API call to prevent rate limit exhaustion
let recentLeaks = []; // Local cache of confirmed sensitive leakage substrings



// Built-in Regex Firewall - Confirmed Leaks (100% Local Hard Block, Skip API completely)
const CONFIRMED_REGEXES = {
  aws_key: /(?:A3T[A-Z0-9]|AKIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ASIA)[A-Z0-9]{16}/,
  google_api: /\bAIza[0-9A-Za-z-_]{35}\b/,
  github_token: /\bghp_[0-9a-zA-Z]{36}\b|\bgithub_pat_[0-9a-zA-Z_]{82}\b/,
  slack_webhook: /https:\/\/hooks\.slack\.com\/services\/[T|B][A-Z0-9]{8}\/[B][A-Z0-9]{8}\/[A-Za-z0-9]{24}/,
  slack_token: /\bxox[bpar]-[0-9]{11,13}-[a-zA-Z0-9]{24}/,
  discord_token: /\b[A-Za-z0-9\-_]{24,28}\.[A-Za-z0-9\-_]{6}\.[A-Za-z0-9\-_]{27,38}\b/,
  discord_webhook: /https:\/\/discord(?:app)?\.com\/api\/webhooks\/[0-9]{17,21}\/[A-Za-z0-9\-_]{68,76}/,
  stripe_key: /\b(?:sk|rk)_(?:live|test)_[0-9a-zA-Z]{24}\b/,
  jwt_token: /\beyJ[A-Za-z0-9-_=]+\.eyJ[A-Za-z0-9-_=]+\.[A-Za-z0-9-_.+/=]+\b/,
  private_key: /-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----|-----BEGIN PGP PRIVATE KEY BLOCK-----/,
  db_connection: /(?:mongodb(?:\+srv)?|mysql|postgresql|redis|sqlite|mssql|oracle):\/\/[%a-zA-Z0-9_\-\.\~+]+:[^@\s]+@[a-zA-Z0-9_\-\.\~%:]+/i,
  korean_rrn: /\b\d{6}\s*-\s*[1-490]\d{6}\b/,
  korean_brn: /\b\d{3}-\d{2}-\d{5}\b/,
  credit_card: /\b(?:\d{4}[-\s]?){3}\d{4}\b|\b3[47]\d{2}[-\s]?\d{6}[-\s]?\d{5}\b/,
  openai_key: /\bsk-(?:proj-)?[a-zA-Z0-9-_]{40,120}\b/,
  anthropic_key: /\bsk-ant-[a-zA-Z0-9-_]{40,100}\b/,
  gcp_service_account: /"type"\s*:\s*"service_account"/i,
  azure_connection: /(?:DefaultEndpointsProtocol=https|AccountName=[a-zA-Z0-9]+;AccountKey=[a-zA-Z0-9+/=]+)/,
  huggingface_key: /\bhf_[a-zA-Z0-9]{34}\b/,
  sendgrid_key: /\bSG\.[a-zA-Z0-9_-]{22}\.[a-zA-Z0-9_-]{43}\b/,
  twilio_key: /\bSK[a-f0-9]{32}\b/,
  notion_key: /\bsecret_[a-zA-Z0-9]{43}\b/,
  figma_token: /\bfigd_[a-zA-Z0-9\-_]{39}\b/
};

// Built-in Regex Firewall - Suspicious Leaks (AI-assisted verification required during sending)
const SUSPICIOUS_REGEXES = {
  generic_secret: /(?:key|token|secret|password|passwd|auth|credential|private_key|api_key|client_secret|db_password)\s*[:=]\s*["'][a-zA-Z0-9_\-\.\~\+\/]{16,}["']/i,
  source_code: /(?:import\s+[\s\S]+?\s+from|const\s+\w+\s*=\s*require|function\s+\w+\s*\(|def\s+\w+\s*\(|public\s+class\s+\w+|struct\s+\w+|#include\s+<\w+>)/,
  pii: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/,
  passport_number: /\b[A-Z]\d{8}\b|\b[A-Z\d]\d[A-Z\d]\d\d{5}\b/i,
  driver_license: /\b\d{2}-\d{2}-\d{6}-\d{2}\b/,
  ip_address: /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/,
  korean_bank: /\b\d{3,6}-\d{2,6}-\d{3,6}(?:-\d{1,3})?\b/
};
const BUILTIN_REGEXES = { ...CONFIRMED_REGEXES, ...SUSPICIOUS_REGEXES };
let customRegexes = [];

// Safe extension message sending helper to prevent "Context Invalidated" or "chrome.runtime undefined" crashes
function safeSendMessage(message, callback) {
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
    try {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          console.warn("[LeakShield] Runtime error during message send:", chrome.runtime.lastError.message);
          callback({ success: false, error: chrome.runtime.lastError.message });
          return;
        }
        callback(response);
      });
    } catch (e) {
      console.error("[LeakShield] Failed to send message to background worker:", e);
      callback({ success: false, error: "Extension context invalidated. Please refresh the page." });
    }
  } else {
    console.error("[LeakShield] Extension context is disconnected. chrome.runtime is undefined.");
    callback({ success: false, error: "Extension context disconnected. Please refresh the page." });
  }
}

// Helper to determine if a matched button is the actual Send button (and not a dropdown options menu)
function isRealSendButton(el) {
  if (!el) return false;

  // Exclude elements that look like dropdown/menu/options trigger
  const ariaLabel = (el.getAttribute('aria-label') || '').toLowerCase();
  const dataTooltip = (el.getAttribute('data-tooltip') || '').toLowerCase();
  const hasPopup = el.getAttribute('aria-haspopup');

  if (hasPopup && hasPopup !== 'false') return false;
  if (el.hasAttribute('aria-expanded')) return false;

  const excludeKeywords = ['option', '옵션', '설정', 'menu', '메뉴', '하위', 'dropdown', '드롭다운'];
  for (const keyword of excludeKeywords) {
    if (ariaLabel.includes(keyword) || dataTooltip.includes(keyword)) {
      return false;
    }
  }
  return true;
}

try {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    // Load custom regexes from storage
    chrome.storage.local.get(['custom_regexes'], (result) => {
      if (result.custom_regexes) {
        updateCustomRegexes(result.custom_regexes);
      }
    });

    // Listen for updates to custom regexes in real-time
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === 'local' && changes.custom_regexes) {
        updateCustomRegexes(changes.custom_regexes.newValue || []);
      }
    });
  }
} catch (e) {
  console.warn("[LeakShield] Storage access failed, extension context may be invalidated:", e);
}

function updateCustomRegexes(regexStrings) {
  customRegexes = [];
  regexStrings.forEach(str => {
    try {
      customRegexes.push(new RegExp(str, 'i')); // Default to case-insensitive matching
    } catch (e) {
      console.error("[LeakShield] Invalid custom regex:", str, e);
    }
  });
  console.log(`[LeakShield] Loaded ${customRegexes.length} custom regex rules.`);
}

// Initialize observation
console.log("[LeakShield] Google Chat Real-Time Leak Detector loaded.");
initObserver();

function initObserver() {
  // Initial check
  setupInputListeners();

  // Watch for dynamic SPA routing changes
  const observer = new MutationObserver(() => {
    setupInputListeners();
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
}

// Find Google Chat SPA contenteditable input textboxes
function setupInputListeners() {
  const inputs = document.querySelectorAll('div[contenteditable="true"][role="textbox"]');
  inputs.forEach(input => {
    if (!input.dataset.leakShieldBound) {
      input.dataset.leakShieldBound = "true";

      // Prevent double triggers and cache override flag
      input.dataset.bypassSecurity = "false";

      // Listen to keystroke and paste events
      input.addEventListener('input', handleInput);
      input.addEventListener('keydown', handleKeydown, true); // Use capture phase to intercept Enter

      // Send button click interception is handled by the global document-level capture handler below.
      // We do NOT use per-button target-phase binding because Google Chat's own handlers
      // are registered at target-phase earlier, so they would fire before ours.
      // Document-level capture phase always fires BEFORE any element-level handlers.

      console.log("[LeakShield] Securely bound to active Google Chat input box.");
    }
  });
}

// Intercept clicks on Google Chat send buttons
function bindSendButton(inputEl) {
  let parent = inputEl.parentElement;
  let sendButton = null;

  // Find Send button relative to input box (up to 5 levels up)
  for (let i = 0; i < 5; i++) {
    if (!parent) break;
    const candidates = parent.querySelectorAll('div[role="button"][aria-label*="Send"], div[role="button"][aria-label*="전송"], div[role="button"][aria-label*="보내기"], div[role="button"][data-tooltip*="Send"], div[role="button"][data-tooltip*="전송"], div[role="button"][data-tooltip*="보내기"]');
    for (const candidate of candidates) {
      if (isRealSendButton(candidate)) {
        sendButton = candidate;
        break;
      }
    }
    if (sendButton) break;
    parent = parent.parentElement;
  }

  if (sendButton) {
    if (!sendButton.dataset.leakShieldBound) {
      sendButton.dataset.leakShieldBound = "true";
      // Intercept both mousedown and click - Google Chat may use either to trigger send
      const makeInterceptHandler = (el, btn) => (e) => {
        const now = Date.now();
        const last = parseInt(btn.dataset.lastInterceptTime || '0');
        if (now - last < 500) return; // debounce: prevent double-fire from mousedown+click pair
        btn.dataset.lastInterceptTime = String(now);
        handleSendClick(e, el, btn);
      };
      sendButton.addEventListener('mousedown', makeInterceptHandler(inputEl, sendButton), true);
      sendButton.addEventListener('click', makeInterceptHandler(inputEl, sendButton), true);
      console.log("[LeakShield] Bound mousedown+click listeners to Send button:", sendButton);
    }
  }
}

// Handle debounced typing inspection
function handleInput(e) {
  const inputEl = e.target;
  const text = inputEl.innerText || "";

  // Reset override and bypass flags on new input
  inputEl.dataset.bypassSecurity = "false";
  inputEl.dataset.doubleEnterPrompted = "false";

  if (text.trim() === "" || text === lastAnalyzedText) return;

  // Clear cached analysis for old text as user is editing it
  lastAnalysisResult = null;

  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => {
    runDebouncedAnalysis(text, inputEl);
  }, 1000); // 1-second debounce to optimize API quota usage
}

// Intercept transmission on Enter press
async function handleKeydown(e) {
  const inputEl = e.target;
  const text = inputEl.innerText || "";

  // Intercept Enter (without Shift) keypress
  if (e.key === 'Enter' && !e.shiftKey) {
    console.log("[LeakShield] Enter detected. Current innerText:", JSON.stringify(text));

    // Handle Ctrl+Enter to bypass security immediately and force-send
    if (e.ctrlKey) {
      console.warn("[LeakShield] Bypass activated by Ctrl+Enter. Force-sending message immediately...");

      if (pendingAnalysis && pendingAnalysis.toastId) {
        dismissToast(pendingAnalysis.toastId);
      }
      if (activeWarningToastId) {
        dismissToast(activeWarningToastId);
        activeWarningToastId = null;
      }

      inputEl.dataset.bypassSecurity = "true";
      inputEl.dataset.doubleEnterPrompted = "false";

      e.preventDefault();
      e.stopPropagation();

      const enterEvent = new KeyboardEvent('keydown', {
        key: 'Enter',
        code: 'Enter',
        keyCode: 13,
        which: 13,
        bubbles: true,
        cancelable: true
      });
      inputEl.dispatchEvent(enterEvent);
      return;
    }

    // If user confirmed to bypass via AI-safe callback
    if (inputEl.dataset.bypassSecurity === "true") {
      console.log("[LeakShield] Security bypassed by user confirmation.");
      inputEl.dataset.bypassSecurity = "false";
      inputEl.dataset.doubleEnterPrompted = "false";
      return;
    }

    // Run Regex Check instantly
    const hasSuspiciousPattern = checkRegexPreFilter(text);
    console.log("[LeakShield] Pre-filter evaluation result:", hasSuspiciousPattern);

    if (hasSuspiciousPattern) {
      // If user presses Enter for the second time, allow send and check in background
      if (inputEl.dataset.doubleEnterPrompted === "true") {
        if (pendingAnalysis && pendingAnalysis.text === text) {
          pendingAnalysis.bypassed = true;
          if (pendingAnalysis.toastId) {
            dismissToast(pendingAnalysis.toastId);
          }
        }
        inputEl.dataset.doubleEnterPrompted = "false";
        inputEl.dataset.bypassSecurity = "false";

        console.warn("[LeakShield] Bypass activated by double Enter. Sending message immediately...");
        return; // Do not call preventDefault/stopPropagation, let it send!
      }

      // First Enter press: block and prompt user
      e.preventDefault();
      e.stopPropagation();
      clearTimeout(debounceTimer);

      console.warn("[LeakShield] First Enter detected. Intercepting for security evaluation...");
      inputEl.dataset.doubleEnterPrompted = "true";

      // Dismiss any active real-time warning toast since we are entering blocking/evaluation state
      if (activeWarningToastId) {
        dismissToast(activeWarningToastId);
        activeWarningToastId = null;
      }

      // Check if we have a local confirmed leak (Level-2 zero-API block!) or cache match
      const localConfirmedLeak = checkConfirmedLeak(text);
      const cachedLeak = checkLocalLeakCache(text);
      const aiResult = localConfirmedLeak || cachedLeak || (lastAnalysisResult && lastAnalysisResult.text === text ? lastAnalysisResult.result : null);

      if (aiResult) {
        console.log("[LeakShield] Using resolved cached analysis result on Enter:", aiResult);

        if (aiResult.isLeak) {
          inputEl.dataset.doubleEnterPrompted = "false"; // Reset bypass since it's confirmed leak
          showToast({
            title: "보안 유출 전송 차단!",
            message: `[${aiResult.category}] 유출 위험이 감지되어 메시지 전송이 보안 차단되었습니다.<br>사유: ${aiResult.reason}<br><br><strong>강제 전송이 필요하시면 <kbd>Ctrl</kbd> + <kbd>Enter</kbd> 키를 누르시면 즉시 전송됩니다.</strong>`,
            riskLevel: aiResult.riskLevel || "CRITICAL",
            category: aiResult.category,
            snippet: aiResult.leakSnippet || text.substring(0, 100),
            duration: 0 // Persistent
          });

          // Log local block to background storage
          if (localConfirmedLeak) {
            safeSendMessage({
              action: 'log_leak',
              leak: {
                snippet: localConfirmedLeak.leakSnippet,
                category: localConfirmedLeak.category,
                riskLevel: localConfirmedLeak.riskLevel,
                reason: localConfirmedLeak.reason,
                fullText: text
              }
            }, () => { });
          }

          console.error("[LeakShield] Hard Block applied by Cybersecurity Sheriff using resolved cached result.");
        } else {
          // Safe! Auto-trigger sending
          showToast({
            title: "보안 안전 검증 완료",
            message: "분석 결과 안전함이 확인되었습니다. 메시지를 자동 전송합니다.",
            riskLevel: "INFO",
            category: "System",
            duration: 4000
          });
          inputEl.dataset.bypassSecurity = "true";
          inputEl.dataset.doubleEnterPrompted = "false";

          // Re-dispatch enter keypress event
          const enterEvent = new KeyboardEvent('keydown', {
            key: 'Enter',
            code: 'Enter',
            keyCode: 13,
            which: 13,
            bubbles: true,
            cancelable: true
          });
          inputEl.dispatchEvent(enterEvent);
        }
        return;
      }

      // If we don't have a cached result, start background AI check
      const loadingToastId = showToast({
        title: "실시간 보안 분석 대기 중...",
        message: "민감 정보 유출 위험이 감지되어 정밀 AI 보안 분석을 진행 중입니다.<br><strong>급한 상황(보안 우회 전송)이시라면 Enter 키를 한 번 더 누르시거나, Ctrl + Enter 키를 누르시면 즉시 전송됩니다.</strong>",
        riskLevel: "WARNING",
        category: "System",
        duration: 0, // Keep until closed
        isLoading: true
      });

      // Save to global pending analysis state
      pendingAnalysis = {
        text: text,
        bypassed: false,
        toastId: loadingToastId
      };

      safeSendMessage({ action: 'analyze_text', text: text }, (response) => {
        console.log("[LeakShield] Enter analysis response:", response);
        // Capture bypassed state before clearing
        const wasBypassed = pendingAnalysis && pendingAnalysis.text === text && pendingAnalysis.bypassed;
        const currentToastId = pendingAnalysis && pendingAnalysis.text === text ? pendingAnalysis.toastId : loadingToastId;

        // Dismiss loading toast
        dismissToast(currentToastId);

        // Clear global pending state if it matches
        if (pendingAnalysis && pendingAnalysis.text === text) {
          pendingAnalysis = null;
        }

        if (response && response.success) {
          const aiResult = response.data;
          console.log("[LeakShield] Enter AI Evaluation:", aiResult);

          // Update cache
          lastAnalysisResult = { text: text, result: aiResult };

          if (aiResult.isLeak) {
            const leakSnippet = aiResult.leakSnippet || text;
            if (leakSnippet && !recentLeaks.includes(leakSnippet)) {
              recentLeaks.push(leakSnippet);
            }
          }

          if (wasBypassed) {
            // Case A: User bypassed and sent the message
            if (aiResult.isLeak) {
              showToast({
                title: "사후 보안 유출 감지!",
                message: `이미 전송된 메시지에서 [${aiResult.category}] 유출 위험이 사후 검증되었습니다.<br>보안 관리자 확인이 필요할 수 있습니다.<br><strong>사유: ${aiResult.reason}</strong>`,
                riskLevel: "CRITICAL",
                category: aiResult.category,
                snippet: aiResult.leakSnippet || text.substring(0, 100),
                duration: 0 // Persistent
              });
            }
          } else {
            // Case B: User waited for assessment
            if (inputEl.innerText.trim() !== "") {
              if (aiResult.isLeak) {
                inputEl.dataset.doubleEnterPrompted = "false"; // Reset bypass since it's confirmed leak
                showToast({
                  title: "보안 유출 전송 차단!",
                  message: `[${aiResult.category}] 유출 위험이 감지되어 메시지 전송이 보안 차단되었습니다.<br>사유: ${aiResult.reason}<br><br><strong>강제 전송이 필요하시면 <kbd>Ctrl</kbd> + <kbd>Enter</kbd> 키를 누르시면 즉시 전송됩니다.</strong>`,
                  riskLevel: aiResult.riskLevel || "CRITICAL",
                  category: aiResult.category,
                  snippet: aiResult.leakSnippet || text.substring(0, 100),
                  duration: 0 // Persistent
                });
                console.error("[LeakShield] Hard Block applied by Cybersecurity Sheriff.");
              } else {
                // Safe! Auto-trigger sending
                showToast({
                  title: "보안 안전 검증 완료",
                  message: "분석 결과 안전함이 확인되었습니다. 메시지를 자동 전송합니다.",
                  riskLevel: "INFO",
                  category: "System",
                  duration: 4000
                });
                inputEl.dataset.bypassSecurity = "true";
                inputEl.dataset.doubleEnterPrompted = "false";

                // Re-dispatch enter keypress event
                const enterEvent = new KeyboardEvent('keydown', {
                  key: 'Enter',
                  code: 'Enter',
                  keyCode: 13,
                  which: 13,
                  bubbles: true,
                  cancelable: true
                });
                inputEl.dispatchEvent(enterEvent);
              }
            }
          }
        } else {
          // Fallback if AI failure
          console.error("[LeakShield] AI analysis error:", response?.error);
          if (!wasBypassed && inputEl.innerText.trim() !== "") {
            const errorMsg = response?.error || "";
            const isRateLimit = errorMsg.includes("quota") || errorMsg.includes("limit") || errorMsg.includes("exceeded");

            if (isRateLimit) {
              showToast({
                title: "API 호출 한도 초과 (Rate Limit)",
                message: "Gemini API 무료 요금제의 분당 호출 한도(20회)를 일시적으로 초과했습니다.<br><strong>전송을 강행하시려면 Enter 키를 한 번 더 누르시거나, <kbd>Ctrl</kbd> + <kbd>Enter</kbd> 키를 누르시면 즉시 전송됩니다.</strong>",
                riskLevel: "WARNING",
                category: "System",
                duration: 0 // Persistent
              });
            } else {
              let title = "보안 분석 일시 오류";
              let message = "API 연결 장애가 발생했습니다. 안전을 위해 전송 전 크레덴셜 정보를 꼭 다시 한 번 확인해 주세요.";

              if (errorMsg.includes("is not configured") || errorMsg.includes("not configured")) {
                title = "API 키 미설정";
                message = "Gemini API 키가 아직 설정되지 않았습니다. 확장 프로그램 설정 페이지에서 API 키를 먼저 입력해 주세요.";
              } else if (errorMsg.includes("API key not valid") || errorMsg.includes("API_KEY_INVALID") || errorMsg.includes("invalid API key") || errorMsg.includes("Invalid API key")) {
                title = "API 키 오류";
                message = "설정된 Gemini API 키가 유효하지 않습니다. 확장 프로그램 설정 페이지에서 올바른 키를 입력했는지 다시 확인해 주세요.";
              } else if (errorMsg) {
                message += `<br><br><strong>상세 정보:</strong> <code>${escapeHtml(errorMsg)}</code>`;
              }
              message += "<br><br><strong>전송을 강행하시려면 Enter 키를 한 번 더 누르시거나, <kbd>Ctrl</kbd> + <kbd>Enter</kbd> 키를 누르시면 즉시 전송됩니다.</strong>";

              showToast({
                title: title,
                message: message,
                riskLevel: "WARNING",
                category: "System",
                duration: 0 // Persistent
              });
            }
          }
        }
      });
    }
  }
}

// Intercept mouse clicks on Google Chat send buttons - [타이밍 버그 완벽 박멸 버전]
async function handleSendClick(e, inputEl, sendButton) {
  const text = inputEl.innerText || "";

  console.log("[LeakShield] 마우스 전송 클릭 가로챔. 텍스트 길이:", text.length);

  // [규칙 1] 팝업이 떠 있는 상태에서 '한 번 더 누르기(우회)'가 정상 승인되어 true가 되었을 때만 최종 전송을 허용합니다.
  if (inputEl.dataset.bypassSecurity === "true") {
    console.log("[LeakShield] 우회 플래그가 true이므로 구글 챗 순정 전송을 허용합니다.");
    inputEl.dataset.bypassSecurity = "false";
    inputEl.dataset.doubleEnterPrompted = "false";
    return; // 👈 여기서 return해야 실제로 서버로 전송됩니다.
  }

  // 1. 엔터 키와 동일하게 정규식 필터를 최우선으로 즉시 가동합니다.
  const hasSuspiciousPattern = checkRegexPreFilter(text);
  console.log("[LeakShield] 정규식 검사 결과 위험 여부:", hasSuspiciousPattern);

  if (hasSuspiciousPattern) {
    // 🛑 [물리 브레이크] 구글 챗의 현재 마우스 전송 동작을 이 자리에서 즉시 사살 (완전 소멸)
    if (e) {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
    }

    // 2. 이미 화면에 경고 팝업이 떠 있는 상태에서 사용자가 종이비행기를 "한 번 더" 누른 경우 (강제 우회 발송)
    if (inputEl.dataset.doubleEnterPrompted === "true") {
      if (pendingAnalysis && pendingAnalysis.text === text) {
        pendingAnalysis.bypassed = true;
        if (pendingAnalysis.toastId) {
          dismissToast(pendingAnalysis.toastId);
        }
      }
      inputEl.dataset.doubleEnterPrompted = "false";
      inputEl.dataset.bypassSecurity = "false";

      console.warn("[LeakShield] 팝업이 떠 있는 상태에서 2회차 연속 클릭 감지. 강제 전송을 실행합니다...");

      // 우회 플래그를 세우고 안전하게 0.05초 뒤 재클릭하여 발송 성공시킴
      inputEl.dataset.bypassSecurity = "true";
      sendButton.dataset.lastInterceptTime = '0';
      setTimeout(() => {
        sendButton.click();
      }, 50);
      return;
    }

    // 3. [핵심] 첫 번째 클릭 시: 발송을 무조건 틀어막고 팝업 가동 상태로 바꾼 뒤 함수를 끝냅니다.
    console.warn("[LeakShield] 1회차 클릭 차단 성공. 더블클릭 대기 상태(doubleEnterPrompted=true)로 전환합니다.");
    inputEl.dataset.doubleEnterPrompted = "true";

    if (activeWarningToastId) {
      dismissToast(activeWarningToastId);
      activeWarningToastId = null;
    }

    // 4. [중요] 이미 화면에 실시간 입력 감지 팝업(.leakshield-toast)이 떠 있다면, 
    // 중복으로 띄우지 않고 전송 차단(락)만 걸어둔 채 여기서 함수를 안전하게 끝냅니다. (이게 엔터와 동일한 원리)
    if (document.querySelector('.leakshield-toast')) {
      console.log("[LeakShield] 이미 화면에 실시간 경고 팝업이 떠 있으므로 전송만 차단하고 대기합니다.");
      return;
    }

    // 5. 만약 팝업이 화면에 없었다면 (X를 눌러서 껐거나 안 떴던 상태라면) 여기서 팝업을 새로 띄워줍니다.
    const localConfirmedLeak = checkConfirmedLeak(text);
    const categoryName = localConfirmedLeak ? localConfirmedLeak.category : "민감 정보";
    const reasonText = localConfirmedLeak ? localConfirmedLeak.reason : "보안 가이드라인 위배 위험";

    showToast({
      title: "보안 유출 전송 차단!",
      message: `[${categoryName}] 유출 위험이 감지되어 메시지 전송이 보안 차단되었습니다.<br>사유: ${reasonText}<br><br><strong>강제 전송이 필요하시면 전송 버튼을 한 번 더 누르시거나, <kbd>Ctrl</kbd> + <kbd>Enter</kbd> 키를 누르시면 즉시 전송됩니다.</strong>`,
      riskLevel: "CRITICAL",
      category: categoryName,
      snippet: text.substring(0, 100),
      duration: 0
    });

    if (localConfirmedLeak) {
      safeSendMessage({
        action: 'log_leak',
        leak: {
          snippet: localConfirmedLeak.leakSnippet,
          category: localConfirmedLeak.category,
          riskLevel: localConfirmedLeak.riskLevel,
          reason: localConfirmedLeak.reason,
          fullText: text
        }
      }, () => { });
    }

    return; // 👈 캐시 로직이나 아래쪽 비동기 AI 분석 구역으로 새어나가지 못하게 단단히 잠금!
  }

  // --------------------------------------------------------------------------------
  // [여기서부터는 기존 안전 문장 전송 및 백그라운드 AI 분석 로직입니다. 변경 없이 그대로 복사되었습니다.]
  // --------------------------------------------------------------------------------
  const localConfirmedLeak = checkConfirmedLeak(text);
  const cachedLeak = checkLocalLeakCache(text);
  const aiResult = localConfirmedLeak || cachedLeak || (lastAnalysisResult && lastAnalysisResult.text === text ? lastAnalysisResult.result : null);

  if (aiResult) {
    console.log("[LeakShield] 캐시된 분석 결과를 사용하여 즉시 처리합니다:", aiResult);

    if (aiResult.isLeak) {
      inputEl.dataset.doubleEnterPrompted = "false";
      showToast({
        title: "보안 유출 전송 차단!",
        message: `[${aiResult.category}] 유출 위험이 감지되어 메시지 전송이 보안 차단되었습니다.<br>사유: ${aiResult.reason}<br><br><strong>강제 전송이 필요하시면 전송 버튼을 한 번 더 누르시거나, <kbd>Ctrl</kbd> + <kbd>Enter</kbd> 키를 누르시면 즉시 전송됩니다.</strong>`,
        riskLevel: aiResult.riskLevel || "CRITICAL",
        category: aiResult.category,
        snippet: aiResult.leakSnippet || text.substring(0, 100),
        duration: 0
      });
    } else {
      showToast({
        title: "보안 안전 검증 완료",
        message: "분석 결과 안전함이 확인되었습니다. 메시지를 자동 전송합니다.",
        riskLevel: "INFO",
        category: "System",
        duration: 4000
      });
      inputEl.dataset.bypassSecurity = "true";
      inputEl.dataset.doubleEnterPrompted = "false";
      sendButton.click();
    }
    return;
  }

  // 캐시가 없을 때 비동기 AI 정밀 분석 시작
  const loadingToastId = showToast({
    title: "실시간 보안 분석 대기 중...",
    message: "민감 정보 유출 위험이 감지되어 정밀 AI 보안 분석을 진행 중입니다.<br><strong>급한 상황이시라면 전송 버튼을 한 번 더 누르시거나, Ctrl + Enter 키를 누르시면 즉시 전송됩니다.</strong>",
    riskLevel: "WARNING",
    category: "System",
    duration: 0,
    isLoading: true
  });

  pendingAnalysis = {
    text: text,
    bypassed: false,
    toastId: loadingToastId
  };

  safeSendMessage({ action: 'analyze_text', text: text }, (response) => {
    console.log("[LeakShield] 비동기 AI 분석 응답 도착:", response);
    const wasBypassed = pendingAnalysis && pendingAnalysis.text === text && pendingAnalysis.bypassed;
    const currentToastId = pendingAnalysis && pendingAnalysis.text === text ? pendingAnalysis.toastId : loadingToastId;

    dismissToast(currentToastId);

    if (pendingAnalysis && pendingAnalysis.text === text) {
      pendingAnalysis = null;
    }

    if (response && response.success) {
      const aiResult = response.data;
      lastAnalysisResult = { text: text, result: aiResult };

      if (aiResult.isLeak) {
        const leakSnippet = aiResult.leakSnippet || text;
        if (leakSnippet && !recentLeaks.includes(leakSnippet)) {
          recentLeaks.push(leakSnippet);
        }
      }

      if (wasBypassed) {
        if (aiResult.isLeak) {
          showToast({
            title: "사후 보안 유출 감지!",
            message: `이미 전송된 메시지에서 [${aiResult.category}] 유출 위험이 사후 검증되었습니다.<br>보안 관리자 확인이 필요할 수 있습니다.<br><strong>사유: ${aiResult.reason}</strong>`,
            riskLevel: "CRITICAL",
            category: aiResult.category,
            snippet: aiResult.leakSnippet || text.substring(0, 100),
            duration: 0
          });
        }
      } else {
        if (inputEl.innerText.trim() !== "") {
          if (aiResult.isLeak) {
            inputEl.dataset.doubleEnterPrompted = "false";
            showToast({
              title: "보안 유출 전송 차단!",
              message: `[${aiResult.category}] 유출 위험이 감지되어 메시지 전송이 보안 차단되었습니다.<br>사유: ${aiResult.reason}<br><br><strong>강제 전송이 필요하시면 전송 버튼을 한 번 더 누르시거나, <kbd>Ctrl</kbd> + <kbd>Enter</kbd> 키를 누르시면 즉시 전송됩니다.</strong>`,
              riskLevel: aiResult.riskLevel || "CRITICAL",
              category: aiResult.category,
              snippet: aiResult.leakSnippet || text.substring(0, 100),
              duration: 0
            });
          } else {
            showToast({
              title: "보안 안전 검증 완료",
              message: "분석 결과 안전함이 확인되었습니다. 메시지를 자동 전송합니다.",
              riskLevel: "INFO",
              category: "System",
              duration: 4000
            });
            inputEl.dataset.bypassSecurity = "true";
            inputEl.dataset.doubleEnterPrompted = "false";
            sendButton.click();
          }
        }
      }
    } else {
      console.error("[LeakShield] AI 분석 실패 또는 한도 초과 오류 처리 영역 생략");
    }
  });
}

// Global document-level interceptor (capture phase) — fires BEFORE any element-level handler.
// This ensures we intercept the send button click before Google Chat's own handlers,
// regardless of whether the button was previously discovered by setupInputListeners.
const SEND_BUTTON_SELECTOR = 'div[role="button"][aria-label*="Send"], div[role="button"][aria-label*="전송"], div[role="button"][aria-label*="보내기"], div[role="button"][data-tooltip*="Send"], div[role="button"][data-tooltip*="전송"], div[role="button"][data-tooltip*="보내기"]';

['pointerdown', 'mousedown', 'click'].forEach(evtType => {
  document.addEventListener(evtType, (e) => {
    const sendButton = e.target.closest(SEND_BUTTON_SELECTOR);
    if (sendButton) {
      if (!isRealSendButton(sendButton)) return;
      const inputEl = document.querySelector('div[contenteditable="true"][role="textbox"]');

      if (inputEl) {
        const text = inputEl.innerText || "";

        if (checkRegexPreFilter(text) && inputEl.dataset.bypassSecurity !== "true") {
          // 1. 이벤트 무조건 취소 시도
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();

          // 2. [물리 차단 치트키] 구글 챗이 긁어갈 입력창 글자를 백업해 두고 순간적으로 삭제!
          // 구글 챗 전송 함수가 실행되더라도 "보낼 내용이 없네?" 하고 전송이 취소됩니다.
          const originalHTML = inputEl.innerHTML;
          inputEl.innerHTML = "";

          if (evtType === 'click') {
            const now = Date.now();
            const last = parseInt(sendButton.dataset.lastInterceptTime || '0');
            if (now - last < 300) return;
            sendButton.dataset.lastInterceptTime = String(now);

            // 3. 보안 팝업 레이어 등장 (질문자님의 팝업 함수 호출)
            handleSendClick(e, inputEl, sendButton);

            // 4. 구글 챗 엔진이 전송 시도를 끝마친 아주 잠깐 뒤(0.1초 후)에 조용히 원래 글자 복구
            setTimeout(() => {
              if (inputEl && inputEl.innerHTML === "") {
                inputEl.innerHTML = originalHTML;
                // 포커스를 다시 주어 사용자가 자연스럽게 수정할 수 있게 만듭니다.
                inputEl.focus();
              }
            }, 100);
          }
          return false;
        }
      }
    }
  }, true); // Capture Phase 1등 가로채기
});


function checkLocalLeakCache(text) {
  for (const leak of recentLeaks) {
    if (text.includes(leak)) {
      return {
        isLeak: true,
        riskLevel: "CRITICAL",
        category: "Credential",
        reason: "이전 단계에서 이미 보안 유출로 판명된 민감 정보(자격 증명 등)가 여전히 포함되어 있습니다.",
        leakSnippet: leak
      };
    }
  }
  return null;
}

// 1차: Local Regex check (returns true if ANY matches)
function checkRegexPreFilter(text) {
  // 1. Check confirmed rules
  for (const [key, regex] of Object.entries(CONFIRMED_REGEXES)) {
    if (regex.test(text)) {
      console.log(`[LeakShield] Confirmed rule matched: [${key}]`);
      return true;
    }
  }

  // 2. Check suspicious rules
  for (const [key, regex] of Object.entries(SUSPICIOUS_REGEXES)) {
    if (regex.test(text)) {
      console.log(`[LeakShield] Suspicious rule matched: [${key}]`);
      return true;
    }
  }

  // 3. Check user-defined custom rules
  for (let i = 0; i < customRegexes.length; i++) {
    if (customRegexes[i].test(text)) {
      console.log(`[LeakShield] Custom rule matched: [${customRegexes[i].source}]`);
      return true;
    }
  }

  return false;
}

// 1.5차: Local Confirmed Leak Direct Engine (Instantly hard block, Zero API requests)
function checkConfirmedLeak(text) {
  for (const [key, regex] of Object.entries(CONFIRMED_REGEXES)) {
    const match = text.match(regex);
    if (match) {
      const categoryName = key.toUpperCase().replace('_', ' ');
      return {
        isLeak: true,
        riskLevel: "CRITICAL",
        category: categoryName,
        reason: `명백한 기밀 자격 증명/데이터(${categoryName}) 노출 양식이 포착되어 전송이 즉시 원천 차단되었습니다.`,
        leakSnippet: match[0]
      };
    }
  }
  return null;
}

// Debounced Background Local-only analysis (Zero API requests during typing)
function runDebouncedAnalysis(text, inputEl) {
  lastAnalyzedText = text;

  // Run Regex Pre-Filter
  const isSuspicious = checkRegexPreFilter(text);
  if (!isSuspicious) {
    // If it's no longer suspicious, dismiss any active warning toast
    if (activeWarningToastId) {
      dismissToast(activeWarningToastId);
      activeWarningToastId = null;
    }
    // Also clear cached result
    lastAnalysisResult = null;
    return;
  }

  // Check Local Leak Cache (Instant match!)
  const cachedLeak = checkLocalLeakCache(text);
  if (cachedLeak) {
    console.log("[LeakShield] Local Leak Cache hit! Displaying cached warning:", cachedLeak.leakSnippet);
    lastAnalysisResult = { text: text, result: cachedLeak };
    if (activeWarningToastId) {
      dismissToast(activeWarningToastId);
    }
    activeWarningToastId = showToast({
      title: "유출 위험 실시간 차단 감지!",
      message: `입력창에 이미 보안 유출로 확인된 [${cachedLeak.category}] 정보가 입력되어 있습니다. 전송 시 전송이 완벽 차단됩니다.`,
      riskLevel: "CRITICAL",
      category: cachedLeak.category,
      snippet: cachedLeak.leakSnippet,
      duration: 0 // Persistent until closed
    });
    return;
  }

  // General Regex hit - warn user locally that sending will trigger final AI evaluation
  console.log("[LeakShield] Local regex hit. Quietly displaying localized warning without API call.");
  // 실시간 진단 함수에서 이미 띄웠으므로, activeWarningToastId가 없는 경우에만 보험용으로 띄워줍니다.
  if (!activeWarningToastId && !document.querySelector('.leakshield-toast')) {
    let detectedCategory = "민감 정보";
    let detectedSnippet = text.substring(0, 100);
    for (const [key, regex] of Object.entries(BUILTIN_REGEXES)) {
      const match = text.match(regex);
      if (match) {
        detectedCategory = key.toUpperCase().replace('_', ' ');
        detectedSnippet = match[0];
        break;
      }
    }

    activeWarningToastId = showToast({
      title: "민감 정보 입력 감지 (로컬 보안 엔진)",
      message: `입력창에 [${detectedCategory}] 양식이 포착되었습니다.<br>전송(Enter)을 누르시면 안전을 위해 <strong>Gemini AI 최종 정밀 보안 검사</strong>를 진행합니다.<br>(급격한 우회 전송이 필요하다면 <strong>Ctrl + Enter</strong>를 누르세요.)`,
      riskLevel: "WARNING",
      category: detectedCategory,
      snippet: detectedSnippet,
      duration: 0 // Persistent until closed
    });
  }
}

const RECOMMENDATIONS = {
  // Cloud & API Keys
  AWS_KEY: "💡 <strong>해결법:</strong> AWS IAM Role을 활용하여 하드코딩을 제거하고, 노출된 키는 AWS 콘솔에서 즉시 <strong>폐기(Deactivate) 및 재생성</strong>하세요.",
  GOOGLE_API: "💡 <strong>해결법:</strong> Google Cloud 콘솔의 'API 및 서비스'에서 해당 API 키의 <strong>접근 제한(IP/HTTP/API 제한)</strong>을 설정하거나 즉시 재발급하세요.",
  GITHUB_TOKEN: "💡 <strong>해결법:</strong> GitHub 개인 액세스 토큰(PAT)이 노출된 경우 GitHub 설정에서 즉시 <strong>토큰을 삭제(Revoke)</strong>하고 새로 발급받으세요.",
  STRIPE_KEY: "💡 <strong>해결법:</strong> Stripe 대시보드의 API Keys 메뉴에서 노출된 키를 즉시 <strong>롤오버(Roll key)</strong>하여 폐기하고 재발급하세요.",
  OPENAI_KEY: "💡 <strong>해결법:</strong> OpenAI API 키가 유출된 경우 OpenAI 플랫폼의 API Keys 메뉴에서 즉시 해당 키를 <strong>삭제(Revoke)</strong>하세요.",
  ANTHROPIC_KEY: "💡 <strong>해결법:</strong> Anthropic 콘솔의 API Keys 메뉴에서 노출된 키를 즉시 <strong>비활성화(Delete)</strong>하고 재발급하세요.",
  HUGGINGFACE_KEY: "💡 <strong>해결법:</strong> HuggingFace 액세스 토큰이 노출되었습니다. 즉시 HuggingFace 계정 설정(Access Tokens)에서 <strong>토큰을 삭제(Revoke)</strong>하고 재발급하세요.",
  SENDGRID_KEY: "💡 <strong>해결법:</strong> SendGrid API 키가 유출된 경우 대량 스팸 메일 발송에 악용될 수 있습니다. SendGrid 콘솔에서 즉시 <strong>해당 키를 삭제</strong>하세요.",
  TWILIO_KEY: "💡 <strong>해결법:</strong> Twilio API 키 도용은 막대한 통신 요금 폭탄을 초래할 수 있습니다. Twilio 콘솔에서 노출된 키를 즉시 <strong>삭제 및 무효화</strong>하세요.",
  NOTION_KEY: "💡 <strong>해결법:</strong> Notion API 시크릿 키가 노출되었습니다. 즉시 Notion 내 통합(Integrations) 설정에서 <strong>해당 시크릿을 재생성(Roll secret)</strong>하세요.",
  FIGMA_TOKEN: "💡 <strong>해결법:</strong> Figma 개인 액세스 토큰이 노출되었습니다. 즉시 Figma 계정 설정의 개인 액세스 토큰 항목에서 <strong>토큰을 회수(Revoke)</strong>하세요.",

  // Webhooks & Messengers
  SLACK_WEBHOOK: "💡 <strong>해결법:</strong> Slack Webhook URL은 무단 알림 발송에 도용될 수 있으므로, Slack 앱 관리자 설정에서 해당 <strong>웹훅을 비활성화/삭제</strong>하세요.",
  SLACK_TOKEN: "💡 <strong>해결법:</strong> Slack API 토큰이 노출된 경우 해당 앱/봇의 토큰을 즉시 <strong>재생성(Regenerate)</strong>하여 이전 토큰을 무효화하세요.",
  DISCORD_TOKEN: "💡 <strong>해결법:</strong> Discord 봇 토큰이 감지되었습니다. Discord Developer Portal에서 봇의 <strong>토큰을 즉시 재설정(Reset Token)</strong>하여 탈취를 방지하세요.",
  DISCORD_WEBHOOK: "💡 <strong>해결법:</strong> Discord 서버 설정의 웹훅(Integrations) 메뉴에서 노출된 <strong>웹훅 주소를 삭제</strong>하고 새로 생성하세요.",

  // Credentials & Systems
  JWT_TOKEN: "💡 <strong>해결법:</strong> JWT 세션 정보는 사용자 로그인 상태를 도용당할 수 있습니다. 세션 만료 시간을 짧게 설정하고 노출 즉시 로그아웃(세션 폐기) 처리를 권장합니다.",
  PRIVATE_KEY: "💡 <strong>해결법:</strong> 프라이빗 키(개인 키)는 암호화 해독 및 서버 직접 접속의 최상위 자산입니다. 노출된 키는 절대 다시 사용하지 마시고, 서버의 <strong>authorized_keys에서 즉시 삭제 및 키페어를 재생성</strong>하세요.",
  DB_CONNECTION: "💡 <strong>해결법:</strong> 데이터베이스 비밀번호가 평문으로 포함되어 있습니다. 즉시 데이터베이스의 <strong>해당 계정 비밀번호를 변경</strong>하고, 공유 시에는 비밀번호 관리도구(Vault)를 이용하세요.",
  GCP_SERVICE_ACCOUNT: "💡 <strong>해결법:</strong> GCP 서비스 계정 키 파일의 유출이 의심됩니다. Google Cloud 콘솔의 'IAM 및 관리자 > 서비스 계정'에서 해당 키를 즉시 <strong>삭제 및 폐기</strong>하세요.",
  AZURE_CONNECTION: "💡 <strong>해결법:</strong> Azure 연결 정보 유출 시 데이터 탈취 위험이 있습니다. Azure 포털에서 해당 스토리지 계정 또는 데이터베이스의 <strong>접속 키(Access Key)를 즉시 재생성(Rotate)</strong>하세요.",

  // Personal Info
  KOREAN_RRN: "💡 <strong>해결법:</strong> 주민등록번호는 법적으로 수집/공유가 금지됩니다. 반드시 뒷자리 7자리를 마스킹 처리(예: 950520-*******)한 후 전송하세요.",
  KOREAN_BRN: "💡 <strong>해결법:</strong> 사내 업무 목적 외 무단 공유는 자제하시고, 필요 시 사업자등록번호의 뒷자리 부분을 마스킹하여 전송하세요.",
  CREDIT_CARD: "💡 <strong>해결법:</strong> 신용카드 번호 유출 시 부정 결제 피해를 입을 수 있습니다. 반드시 중간 8자리를 마스킹(예: 1234-****-****-5678)하여 공유하세요.",
  PASSPORT_NUMBER: "💡 <strong>해결법:</strong> 여권번호 유출 방지를 위해 식별 번호 중 뒷자리 4~5자리를 마스킹 처리하여 안전하게 발송하세요.",
  DRIVER_LICENSE: "💡 <strong>해결법:</strong> 운전면허 번호 유출 방지를 위해 지역 코드를 제외한 일련번호 뒷부분을 마스킹하여 전송하세요.",
  KOREAN_BANK: "💡 <strong>해결법:</strong> 계좌번호 유출 방지를 위해 가급적 계좌번호의 중간 부분을 마스킹 처리(예: 110-***-123456)한 뒤 예금주명과 함께 발송하세요.",

  // Heuristics
  GENERIC_SECRET: "💡 <strong>해결법:</strong> 소스 코드나 텍스트 파일 내 자격 증명이 노출되었습니다. 소스 코드 배정 방식 대신 환경변수(`.env`)를 활용하여 비밀정보를 격리하세요.",
  SOURCE_CODE: "💡 <strong>해결법:</strong> 사내 소스 코드는 지적 자산 및 잠재적 취약점 누출 경로입니다. 공유가 필수적이라면 핵심 로직만 간추리고 기밀 키워드가 제거되었는지 다시 점검하세요.",
  PII: "💡 <strong>해결법:</strong> 이메일 등 개인 식별 정보가 감지되었습니다. 불필요한 개인 정보 공유는 피하시고, 식별 불가능하도록 부분 마스킹 처리를 권장합니다.",
  IP_ADDRESS: "💡 <strong>해결법:</strong> 내부망/서버 IP 주소 노출은 해킹 공격의 표적이 될 수 있습니다. 공유 시 가급적 일부 대역을 마스킹(예: 192.168.*.*)하여 사용하세요.",

  // General Categories (Fallback from Gemini AI)
  CREDENTIAL: "💡 <strong>해결법:</strong> 기밀 자격 증명이 노출되었습니다. 해당 키/토큰을 즉시 비활성화하거나 재생성하시고, 코드 하드코딩 대신 환경변수나 시큐어 볼트(Vault) 서비스를 사용해 주세요.",
  SYSTEM: "💡 <strong>해결법:</strong> 서버 정보 및 내부 시스템 아키텍처 노출 위험이 있습니다. 중요 식별자나 IP 대역을 마스킹하고, 권한이 있는 담당자에게만 보안 채널로 공유해 주세요."
};

// Toast Manager
function getOrCreateToastContainer() {
  let container = document.getElementById('leak-shield-toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'leak-shield-toast-container';
    document.body.appendChild(container);
  }
  return container;
}

function showToast({ title, message, riskLevel, category, snippet, duration = 8000, isLoading = false }) {
  const container = getOrCreateToastContainer();
  const id = 'toast_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);

  const toast = document.createElement('div');
  toast.className = `leak-shield-toast leak-shield-toast-${riskLevel.toLowerCase()}`;
  toast.id = id;

  // Premium glow and border animations
  let borderGlow = '';
  if (riskLevel === 'CRITICAL') borderGlow = 'box-shadow: 0 0 15px rgba(239, 68, 68, 0.4);';
  else if (riskLevel === 'WARNING') borderGlow = 'box-shadow: 0 0 15px rgba(245, 158, 11, 0.3);';
  else borderGlow = 'box-shadow: 0 0 15px rgba(59, 130, 246, 0.2);';

  toast.setAttribute('style', borderGlow);

  let iconHtml = '';
  if (isLoading) {
    iconHtml = `<div class="leak-shield-spinner"></div>`;
  } else {
    const iconColor = riskLevel === 'CRITICAL' ? '#ef4444' : (riskLevel === 'WARNING' ? '#f59e0b' : '#3b82f6');
    iconHtml = `
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="${iconColor}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
      </svg>
    `;
  }

  const badgeColor = riskLevel === 'CRITICAL' ? 'bg-red' : (riskLevel === 'WARNING' ? 'bg-amber' : 'bg-blue');

  // Look up recommendation advice based on the category
  let recommendationHtml = '';
  if (category) {
    const key = category.toUpperCase().trim().replace(/ /g, '_');
    if (RECOMMENDATIONS[key]) {
      recommendationHtml = `
        <div class="leak-shield-toast-recommendation">
          ${RECOMMENDATIONS[key]}
        </div>
      `;
    }
  }

  toast.innerHTML = `
    <div class="leak-shield-toast-header">
      <div class="leak-shield-toast-icon">${iconHtml}</div>
      <div class="leak-shield-toast-title-area">
        <span class="leak-shield-toast-title">${title}</span>
        <span class="leak-shield-toast-badge ${badgeColor}">${category}</span>
      </div>
      <button class="leak-shield-toast-close">&times;</button>
    </div>
    <div class="leak-shield-toast-body">
      <p class="leak-shield-toast-text">${message.replace(/\n/g, '<br>')}</p>
      ${recommendationHtml}
      ${snippet ? `
        <div class="leak-shield-toast-snippet">
          <code>${escapeHtml(snippet)}</code>
        </div>
      ` : ''}
    </div>
  `;

  // Append toast
  container.appendChild(toast);

  // Smooth slide-in
  setTimeout(() => {
    toast.classList.add('visible');
  }, 50);

  // Close Event
  toast.querySelector('.leak-shield-toast-close').addEventListener('click', () => {
    dismissToast(id);
  });

  // Auto-dismiss setup
  if (duration > 0) {
    setTimeout(() => {
      dismissToast(id);
    }, duration);
  }

  return id;
}

function dismissToast(id) {
  const toast = document.getElementById(id);
  if (toast) {
    toast.classList.remove('visible');
    toast.classList.add('dismissed');
    setTimeout(() => {
      toast.remove();
    }, 400); // Wait for transition out
  }
}

function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return text.replace(/[&<>"']/g, function (m) { return map[m]; });
}

/****************************************************************************
 * LeakShield - 선제적 UI 잠금 시스템 (Proactive UI Lock Engine)
 * [진입 즉시 무조건 선잠금 버전 - 파일 최하단 덮어쓰기]
 ****************************************************************************/
(() => {
  const SEND_BUTTON_SELECTOR = '[role="button"][aria-label*="Send"], [role="button"][aria-label*="전송"], [role="button"][aria-label*="보내기"], [role="button"][data-tooltip*="Send"], [role="button"][data-tooltip*="전송"], [role="button"][data-tooltip*="보내기"], button[aria-label*="Send"], button[aria-label*="전송"], button[aria-label*="보내기"]';
  const LOCK_SHIELD_ID = 'leakshield-proactive-button-lock';

  function getRealSendButton() {
    const candidates = document.querySelectorAll(SEND_BUTTON_SELECTOR);
    for (const candidate of candidates) {
      if (isRealSendButton(candidate)) {
        return candidate;
      }
    }
    return null;
  }

  function 제어_물리잠금벽(잠글까) {
    const sendButton = getRealSendButton();
    if (!sendButton) return;

    let lockShield = document.getElementById(LOCK_SHIELD_ID);

    if (잠글까) {
      const rect = sendButton.getBoundingClientRect();
      // rect의 크기가 0이 아닐 때만 물리 잠금벽을 씌움
      if (rect.width === 0 || rect.height === 0) {
        if (lockShield) {
          lockShield.style.display = 'none';
        }
        return;
      }

      if (!lockShield) {
        lockShield = document.createElement('div');
        lockShield.id = LOCK_SHIELD_ID;
        lockShield.className = 'leakshield-proactive-lock-wall';

        // inline style로 물리적 팝업 잠금(Overlay) 속성 설정
        lockShield.style.position = 'fixed';
        lockShield.style.zIndex = '2147483647';
        lockShield.style.cursor = 'not-allowed';
        lockShield.style.backgroundColor = 'rgba(239, 68, 68, 0.2)'; // 빨간 오버레이를 통해 시각적으로 팝업(가림) 인지 유도
        lockShield.style.border = '2.5px solid #ef4444';
        lockShield.style.borderRadius = '50%';
        lockShield.style.boxShadow = '0 0 10px rgba(239, 68, 68, 0.6)';

        lockShield.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();

          console.warn("[LeakShield] 잠금벽 전면 충돌! 위험 문장 수정을 유도하거나 빈 입력 상태입니다.");

          const inputEl = document.querySelector('div[contenteditable="true"][role="textbox"]');
          if (inputEl && sendButton) {
            // 텍스트가 있을 때만 기존 팝업 함수를 트리거합니다.
            if ((inputEl.innerText || "").trim().length > 0) {
              handleSendClick(e, inputEl, sendButton);
            }
          }
        }, true);

        document.body.appendChild(lockShield);
      }

      lockShield.style.top = `${rect.top}px`;
      lockShield.style.left = `${rect.left}px`;
      lockShield.style.width = `${rect.width}px`;
      lockShield.style.height = `${rect.height}px`;
      lockShield.style.display = 'block';
    } else {
      if (lockShield) {
        lockShield.style.display = 'none';
      }
    }
  }

  function 실시간_텍스트_보안진단() {
    const inputEl = document.querySelector('div[contenteditable="true"][role="textbox"]');
    const sendButton = getRealSendButton();

    // 전송 버튼 자체가 없다면 잠금벽 제어를 할 수 없으므로 해제 처리
    if (!sendButton) {
      제어_물리잠금벽(false);
      return;
    }

    // 1. 채팅 페이지에 들어왔으나 아직 입력창 요소를 찾지 못한 경우 (진입 초기), 무조건 전송을 잠급니다.
    if (!inputEl) {
      제어_물리잠금벽(true);
      if (activeWarningToastId) {
        dismissToast(activeWarningToastId);
        activeWarningToastId = null;
      }
      return;
    }

    const text = (inputEl.innerText || "").trim();

    // 2. 강제 우회 상태가 활성화되어 있다면 즉시 잠금을 해제하여 전송 길을 열어줍니다.
    if (inputEl.dataset.bypassSecurity === "true") {
      제어_물리잠금벽(false);
      return;
    }

    // 3. 입력창이 완전히 비어있다면, 차단막은 켜고 경고창은 지웁니다.
    if (text === "") {
      제어_물리잠금벽(true);
      if (activeWarningToastId) {
        dismissToast(activeWarningToastId);
        activeWarningToastId = null;
      }
      return;
    }

    // 4. 정규식 필터에 걸리는 위험 문장이라면 "무조건 잠금" 및 "즉시 경고 Toast 노출"
    if (checkRegexPreFilter(text)) {
      제어_물리잠금벽(true);  // 🚨 위험 시 빨간 막 가동!

      // 아직 경고 팝업이 없는 상태라면 즉시 띄웁니다.
      if (!activeWarningToastId && !document.querySelector('.leakshield-toast')) {
        let detectedCategory = "민감 정보";
        let detectedSnippet = text.substring(0, 100);
        for (const [key, regex] of Object.entries(BUILTIN_REGEXES)) {
          const match = text.match(regex);
          if (match) {
            detectedCategory = key.toUpperCase().replace('_', ' ');
            detectedSnippet = match[0];
            break;
          }
        }
        activeWarningToastId = showToast({
          title: "민감 정보 입력 감지 (로컬 보안 엔진)",
          message: `입력창에 [${detectedCategory}] 양식이 포착되었습니다.<br>전송(Enter)을 누르시면 안전을 위해 <strong>Gemini AI 최종 정밀 보안 검사</strong>를 진행합니다.<br>(급격한 우회 전송이 필요하다면 <strong>Ctrl + Enter</strong>를 누르세요.)`,
          riskLevel: "WARNING",
          category: detectedCategory,
          snippet: detectedSnippet,
          duration: 0 // 사용자가 고치거나 강제우회 전송할 때까지 유지
        });
      }
    } else {
      // 5. 무언가 입력되었고, 정규식 검사 결과 안전함이 100% 확정되었을 때만 빨간 막을 치우고, 경고창도 지웁니다.
      제어_물리잠금벽(false); // ✨ 잠금 해제 (순정 버튼 노출)

      if (activeWarningToastId) {
        dismissToast(activeWarningToastId);
        activeWarningToastId = null;
      }
    }
  }

  // 사용자의 실시간 액션 감지
  document.addEventListener('input', 실시간_텍스트_보안진단);
  document.addEventListener('keyup', 실시간_텍스트_보안진단);
  document.addEventListener('mousemove', 실시간_텍스트_보안진단, true);

  window.addEventListener('resize', () => {
    const lockShield = document.getElementById(LOCK_SHIELD_ID);
    if (lockShield && lockShield.style.display === 'block') {
      제어_물리잠금벽(true);
    }
  });

  // 중요: 구글 챗 방에 진입하자마자 입력창이 빈 상태일 때 버튼을 바로 낚아채기 위해 
  // 인터벌 주기를 0.2초(200ms)로 더 촘촘하게 당겨서 선제 공격을 날립니다.
  setInterval(실시간_텍스트_보안진단, 200);
})();